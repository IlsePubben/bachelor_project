reward_apple = 1
reward_dead = -10
reward_approach_apple = 0
reward_avoid_apple = 0
initial_snake_length = 3
game_size = 8
max_epochs = 7000

start_epsilon = 0.1
final_epsilon = 0
epsilon = start_epsilon
discount_factor = 0.99
learning_rate_q = 0.001
learning_rate_v = learning_rate_q
learning_rate_a = learning_rate_q

algorithm = "" 
